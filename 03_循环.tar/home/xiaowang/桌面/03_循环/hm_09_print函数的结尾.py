print("*")
print("*")

print("*",end="")
print("*")

print("*",end="---")
print("*")