i = 0
sum = 0
while i <= 100:
    print(i)
    sum += i
    i += 1
print("0-100之间的数字求和结果:%d"%sum)