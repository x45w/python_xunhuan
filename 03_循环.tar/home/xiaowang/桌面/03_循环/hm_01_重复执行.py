
print("Hello python")
print("Hello python")
print("Hello python")
print("Hello python")
print("Hello python")