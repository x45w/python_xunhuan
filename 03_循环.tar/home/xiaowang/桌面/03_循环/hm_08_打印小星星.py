row = 1
while row <=5:
    print("*" * row)
    row += 1