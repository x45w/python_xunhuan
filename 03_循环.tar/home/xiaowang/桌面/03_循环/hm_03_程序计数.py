i = 0

while i < 3:

    print("Hello Python")

    i = i + 1
print("循环结束后,i = %d"%i)